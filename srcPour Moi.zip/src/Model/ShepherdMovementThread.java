/*package Model;

import Model.Entity;
import Model.EntityMovementThread;
import Model.Exceptions.InvalidCoordinates;

public class ShepherdMovementThread extends EntityMovementThread {
    public static final int DELAY = 50; // berger plus rapide

    private Entity e;
    public ShepherdMovementThread(Entity e) {
        super(e);
    }

    @Override
    public void run() {
        if (e == null) {
            System.err.println("Erreur : l'entit� dans ShepherdMovementThread est null.");
            return;
        }
        while (e.hasMovements()) {

            try {
                e.move();
                Thread.sleep(DELAY);
            } catch (InterruptedException | InvalidCoordinates ex) {
                ex.printStackTrace();
            }
        }
    }
}*/
