package Model.TimePassing;

public class Time {
}
