package Model.Predators;

import Model.Entity;
import Model.Farm;
import Model.Positionnable;
import Model.Spot;

import java.util.Iterator;


public abstract class Den extends Positionnable implements Runnable {
    private static final int MAX_WOLVES = 5;
    protected Farm farm;
    public boolean active; //



    public Den(Spot s, Farm farm) {
        super(s);

        this.farm = farm;
        this.active = true;
    }

    public void reactToAreaChange() {
        active = !this.position.isProtectedArea();
    }

    public boolean isActive(){return active;}

    /**
     * M�thode abstraite qui spawn un pr�dateur (Wolf ou Fox) depuis le den.
     */
    protected abstract void spawnPredator();
    private int numberOfLivingWolves() {
        int count = 0;
        for (Iterator<Entity> it = farm.getEntities(); it.hasNext(); ) {
            Entity entity = it.next();
            if (entity instanceof Wolf) {
                count++;
            }
        }
        return count;
    }

    @Override
    public void run() {
        while (active) {

            // Sinon, le den spawn un pr�dateur
            if(numberOfLivingWolves() < MAX_WOLVES) spawnPredator();
            try {
                Thread.sleep(5000); // D�lai entre chaque spawn
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

}