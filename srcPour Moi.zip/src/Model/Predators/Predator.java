package Model.Predators;

import Model.Entity;
import Model.Farm;
import Model.Spot;
import java.util.ArrayList;
import java.util.List;

public abstract class Predator extends Entity implements Runnable {
    public static final int DELAY_PREDATOR = 1000;
    protected Farm farm;
    private boolean isDead;
    private Den parentDen;
    public void setParentDen(Den d) {
        this.parentDen = d;
    }

    public Den getParentDen() {
        return parentDen;
    }
    public Predator(Spot s, Farm farm) {
        super(s);
        this.farm = farm;
        isDead = false;
    }
    public boolean getIsDead(){
        return isDead;
    }
    public void setIsDead(boolean isDead) {
        this.isDead = isDead;
    }

    /**
     * Méthode qui vérifie les cases adjacentes et tue les proies correspondantes.
     */
    protected abstract void checkAndKillPrey();
    public void reactToAreaChange() {
        isDead = true;
    }

}
