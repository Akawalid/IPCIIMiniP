/*package Model.Predators; // ou dans un package appropri�

import Model.Farm;
import Model.Predators.Den;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DenActivatorThread extends Thread {
    private final Farm farm;
    public static final int ACTIVATION_DELAY = 5000; // Activation toutes les 5 secondes

    public DenActivatorThread(Farm farm) {
        this.farm = farm;
    }

    @Override
    public void run() {
        while (!isInterrupted()) {

            System.out.println("Initialisation p�riodique des dens de pr�dateurs...");

            // Appel de l'initialisation des dens dans la ferme
            farm.initPredators();

            // Pause avant la prochaine initialisation
            try {
                Thread.sleep(ACTIVATION_DELAY);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("Thread DenActivator arr�t�.");
    }
}
*/