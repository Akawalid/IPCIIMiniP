package Model.Predators;

import Model.Entity;
import Model.Exceptions.UnauthorizedAction;
import Model.Farm;
import Model.FarmAnimals.FarmAnimal;
import Model.Shepherd.FindPath;
import Model.Spot;
import Model.Exceptions.InvalidCoordinates;

import java.util.*;

public class Wolf extends Predator {

    public Wolf(Spot s, Farm farm) {
        super(s, farm);
    }

    @Override
    public void run() {
        //Random rand = new Random();
        while (!getIsDead()) { // Ajout de la condition de sortie

            // Vérifier si le Den parent est présent et actif.
            if (getParentDen() == null || !getParentDen().isActive()) {
                System.out.printf("Prédateur %s (ID: %d) supprimé : Den parent inactif ou absent.%n",
                        getSpecies(), getId());
                setIsDead(true);
                farm.removeEntity(this);  // Retire le prédateur du modèle
                break;  // Sortir de la boucle pour terminer le thread
            }

            // 1. Vérifier et tuer toute proie adjacente (Ewe ou Sheep)
            checkAndKillPrey();

            // 2. Chercher la proie la plus proche
            FarmAnimal target = findClosestPrey();
            if (target != null) {
                // Utiliser FindPath pour calculer le chemin vers la proie
                ArrayDeque<Spot> path = FindPath.findPath(this.getPosition(), target.getPosition());
                this.setPath(path); // Définit le chemin dans l'entité
                // Démarrage du thread de mouvement si des mouvements sont en file
                if (this.hasMovements() && (this.getThread() == null || !this.getThread().isAlive())) {
                    this.startNewThread();
                }
            /*} else {  // TODO a été Enelbver pour éviter le déplacement aléatoire
                // Si aucune proie n'est détectée, se déplacer aléatoirement
                List<Spot> freeSpots = new ArrayList<>();
                for (Spot neighbor : farm.getAdjacentSpots(this.getPosition())) {
                    if (neighbor.isTraversable()) {
                        freeSpots.add(neighbor);
                    }
                }
                if (!freeSpots.isEmpty()) {
                    Spot next = freeSpots.get(rand.nextInt(freeSpots.size()));
                    // Créer un chemin d'une seule case pour le déplacement
                    ArrayDeque<Spot> singleStep = new ArrayDeque<>();
                    singleStep.add(next);
                    this.setPath(singleStep);
                    // Démarrage du thread de mouvement si nécessaire
                    if (this.getThread() == null || !this.getThread().isAlive()) {
                        this.startNewThread();
                    }
                }*/
            /*} else { //TODO déjà fait dans la class Farm méthode removePredatorStructuresIfNoLivestock()
                System.out.printf("Aucune proie détectée pour le Wolf (ID: %d), le wolf meurt.%n", getId());
                setIsDead(true);
                farm.removeEntity(this);
                break;*/
            }
            try {
                Thread.sleep(2000); // Pause d'une seconde entre chaque cycle
            } catch (InterruptedException e) {
                break;
            }
        }
    }


    @Override
    protected void checkAndKillPrey() {
        for (Spot neighbor : farm.getAdjacentSpots(this.getPosition())) {
            Entity entity = farm.getEntityInSpot(neighbor.getRow(), neighbor.getCol());
            if ( entity instanceof FarmAnimal) { // entity != null &&
                String species = ((FarmAnimal) entity).getSpecies();
                // Pour le wolf, la proie peut être une Ewe ou un Sheep
                if (species.equals("Ewe") || species.equals("Sheep")) {
                    farm.removeEntity(entity);
                    entity.getPosition().setPositionnable(null); // Libérer la cellule
                    entity.getPosition().setIsTraversable(true);

                }
            }
        }
    }

    /**
     * Recherche la proie la plus proche (Ewe ou Sheep) parmi les entit�s de la ferme.
     */
    private FarmAnimal findClosestPrey() {
        FarmAnimal closest = null;
        double minDistance = Double.MAX_VALUE;
        for (Iterator<Entity> it = farm.getEntities(); it.hasNext(); ) {
            Entity e = it.next();
            if (e instanceof FarmAnimal) {
                FarmAnimal animal = (FarmAnimal) e;
                String species = animal.getSpecies();
                if (species.equals("Ewe") || species.equals("Sheep")) {
                    double distance = this.getPosition().distanceTo(animal.getPosition());
                    if (distance < minDistance) {
                        minDistance = distance;
                        closest = animal;
                    }
                }
            }
        }
        return closest;
    }



    //J'ai du override parce que ca me disait de le faire sinon il y avait des erreurs
    @Override //TODO
    public String getSpecies() {
        return "Wolf";
    }
    @Override //TODO
    public int get_buying_price() {
        return 0;
    }

    @Override
    public int get_selling_price() throws UnauthorizedAction {
        return 0;
    }
}
