package Model.Predators;

import Model.Entity;
import Model.Exceptions.UnauthorizedAction;
import Model.Farm;
import Model.FarmAnimals.FarmAnimal;
import Model.FarmAnimals.Hen;
import Model.Exceptions.InvalidCoordinates;
import Model.Shepherd.FindPath;
import Model.Spot;

import java.util.*;

public class Fox extends Predator {

    public Fox(Spot s, Farm farm) {
        super(s, farm);
    }

    @Override
    public void run() {
        //Random rand = new Random();
        while (!getIsDead()) {

            // Vérifier si le Den parent est présent et actif.
            if (getParentDen() == null || !getParentDen().isActive()) {
                System.out.printf("Prédateur %s (ID: %d) supprimé : Den parent inactif ou absent.%n",
                        getSpecies(), getId());
                setIsDead(true);
                farm.removeEntity(this);  // Retire le prédateur du modèle
                break;  // Sortir de la boucle pour terminer le thread
            }

            // 1. V�rifier et tuer toute proie adjacente (Ewe ou Sheep)
            checkAndKillPrey();

            // 2. Chercher la proie la plus proche
            FarmAnimal target = findClosestPrey();
            if (target != null) {
                // Utiliser FindPath pour calculer le chemin vers la proie
                ArrayDeque<Spot> path = FindPath.findPath(this.getPosition(), target.getPosition());
                this.setPath(path); // D�finit le chemin dans l'entit�
                // Démarrage du thread de mouvement si des mouvements sont en file
                if (this.hasMovements() && (this.getThread() == null || !this.getThread().isAlive())) {
                    this.startNewThread();
                }

            }
            try {
                Thread.sleep(2000); // Pause d'une seconde entre chaque cycle
            } catch (InterruptedException e) {
                break;
            }
        }
    }


    @Override
    protected void checkAndKillPrey() {
        // Vérifie les cases adjacentes pour trouver et tuer une proie (Hen)
        for (Spot neighbor : farm.getAdjacentSpots(this.getPosition())) {
            Entity entity = farm.getEntityInSpot(neighbor.getRow(), neighbor.getCol());
            if (entity instanceof FarmAnimal) {
                String species = ((FarmAnimal) entity).getSpecies();
                // Pour Fox, la proie doit être un Hen
                if (species.equals("Hen")) {
                    farm.removeEntity(entity);
                    entity.getPosition().setPositionnable(null); // Libérer la cellule
                    entity.getPosition().setIsTraversable(true);
                }
            }
        }
    }

    /**
     * Recherche la proie la plus proche (un Hen) parmi les entités de la ferme.
     */
    private FarmAnimal findClosestPrey() {
        FarmAnimal closest = null;
        double minDistance = Double.MAX_VALUE;
        for (Iterator<Entity> it = farm.getEntities(); it.hasNext(); ) {
            Entity e = it.next();
            if (e instanceof FarmAnimal) {
                FarmAnimal animal = (FarmAnimal) e;
                String species = animal.getSpecies();
                if (species.equals("Hen")) {
                    double distance = this.getPosition().distanceTo(animal.getPosition());
                    if (distance < minDistance) {
                        minDistance = distance;
                        closest = animal;
                    }
                }
            }
        }
        return closest;
    }

    @Override
    public String getSpecies() {
        return null;
    }

    @Override
    public int get_buying_price() {
        return 0;
    }

    @Override
    public int get_selling_price() throws UnauthorizedAction {
        return 0;
    }
}
