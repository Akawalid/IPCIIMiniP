package Model;

import Model.Exceptions.InvalidCoordinates;
import Model.Exceptions.UnauthorizedAction;
import Model.Shepherd.FindPath;

import java.util.*;

public abstract class Entity extends Positionnable implements Comparable<Entity> {
    //This class represents all the living creatures of the game
    //They share proprieties like: move, position, name and id
    //It is abstract because we shouldn't have an animal of type that is strictly equal to entity (absurd).
    private static int idCounter = 0;
    //We need this attribute here in order to get the position of the active entity from the controller easily
    protected ArrayDeque<Spot> path; // Queue to store movements
    private EntityMovementThread thread;
    protected final int id;
    // An entity's priority depends on its distance to the target:
    // The closer it is to the target, the higher its priority.
    // Therefore, priority is determined by the remaining distance to the target.
    // TODO: Les bêtes bougent ? Si oui, alors il faut bien adapter la priorité ainsi que les méthodes qui en dépendent pour leurs mouvements.

    public Entity(Spot position){
        super(position);

        id = idCounter;
        idCounter++;

        path = new ArrayDeque<>();
    }

    public int getId(){
        return id;
    }
    public abstract String getSpecies();

    //move is an abstract methode because each entity has its own way of moving.
    //move method throws InvalidCoordinates in case if the user clicks on an invalid spot such as a tree, or a rock...
    public synchronized void move() throws InvalidCoordinates {
        // Vérifier que la méthode est appelée par l'EntityMovementThread associé
        //if (!(Thread.currentThread() instanceof EntityMovementThread)) {
           // throw new IllegalStateException("move() must be called only by the EntityMovementThread.");
        //}

        if (path.isEmpty()) {
            return; // No movements in the queue
        }
        //if the next spot is traversable this means that another entity just came to cross it
        //we wait until this spot becomes free, then we cross
        if(!path.peek().isTraversable()) {
            //In conflict case, we return false
            handleConflict();
        };

        // Get the next spot from the queue
        //assert(!path.isEmpty());
        //setPosition(path.poll()); // Move to the new position

        Spot nextSpot = path.poll();
        if (nextSpot == null || !nextSpot.isTraversable()) {
            return; // ou recalculer le chemin
        }
        setPosition(nextSpot);


    }




    /*public synchronized void move() throws InvalidCoordinates {
        // Vérifier que la file de mouvements n'est pas vide
        if (path.isEmpty()) {
            return;
        }

        // Récupérer l'ancien Spot
        Spot oldSpot = this.getPosition();

        // Libérer l'ancien Spot de façon atomique
        synchronized(oldSpot) {
            System.out.printf("Libération du Spot (%d, %d) pour %s (ID:%d)%n",
                    oldSpot.getRow(), oldSpot.getCol(), this.getSpecies(), this.getId());
            // Réinitialiser le spot : il n'est plus occupé
            oldSpot.setPositionnable(null);
            oldSpot.setIsTraversable(true);
            // Vous pouvez éventuellement ajouter d'autres logs ici
        }

        // Récupérer le prochain Spot dans la file
        Spot nextSpot = path.poll();
        if (nextSpot == null) {
            return;
        }

        // Optionnel : attendre que nextSpot soit réellement traversable
        while (!nextSpot.isTraversable()) {
            System.out.printf("Attente : le Spot (%d, %d) n'est pas traversable pour %s (ID:%d)%n",
                    nextSpot.getRow(), nextSpot.getCol(), this.getSpecies(), this.getId());
            try {
                Thread.sleep(50); // Attendre quelques millisecondes avant de réessayer
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        // Mise à jour atomique de la nouvelle position
        synchronized(nextSpot) {
            // Vérifier une dernière fois que le spot est libre avant de s'y positionner
            if (!nextSpot.isTraversable()) {
                System.out.printf("Le Spot (%d, %d) est devenu non traversable, annulation du déplacement pour %s (ID:%d)%n",
                        nextSpot.getRow(), nextSpot.getCol(), this.getSpecies(), this.getId());
                return; // Ou recalculer un chemin selon votre logique
            }
            // Positionner l'entité sur le nouveau spot
            setPosition(nextSpot);
            System.out.printf("Déplacement effectué pour %s (ID:%d) vers le Spot (%d, %d)%n",
                    this.getSpecies(), this.getId(), nextSpot.getRow(), nextSpot.getCol());
        }
    }*/

    protected void handleConflict(){
        /*
            We have two cases:
                Recalculate path: in blockage case, when two entities move in opposite directions, or a new
                    entities is put in the middle of the path.
                Wait
        */
        //Blockage case
        assert(path.peek() != null );
        assert (path.peek().getPositionnable()!= null);

        assert(path.peek().getPositionnable() instanceof Entity);
        if(((Entity) path.peek().getPositionnable()).path.isEmpty()){
            //recalculate path
            Spot destination = path.pop();
            FindPath.findPath(this.position, destination);
            return;
        }
        if (((Entity) path.peek().getPositionnable()).path.peek() == this.position) {
            //the greater one calculates the path by convention
            if(compareTo(((Entity) path.peek().getPositionnable())) > 0){
                Spot destination = path.pop();
                setPath(
                        FindPath.findPath(this.position, destination)
                );
            } else {
                //the other one waits
                Spot destination = ((Entity) path.peek().getPositionnable()).path.pop();
                ((Entity) path.peek().getPositionnable()).setPath(
                        FindPath.findPath(this.position, destination)
                );
            }
        }
        //here we wait;
        //No code is needed

    }
    public void setPath(ArrayDeque<Spot> q){
        path = q;
    }
    public boolean hasMovements(){return !path.isEmpty();}

    //these methods are implemented to use HashSets of Entities
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Entity entity = (Entity) o;
        return id == entity.id; // Assuming Entity has a unique ID field
    }
    @Override
    public int hashCode() {
        return Objects.hash(id); // Same field as used in equals()
    }
    public EntityMovementThread getThread(){return  thread;}
    public void startNewThread(){
        // We store a thread in a attribute to avoid getting unexpected errors when the user changes the path
        //of a shepherd in the middle of its movement.
        thread = new EntityMovementThread(this);
        thread.start();
    }

    @Override
    public int compareTo(Entity other) {
        //Lexicographic order (DISTANCE_TO_TARGET, ID)
        //TODO: is it the same for all entities? it is used to decide which entity goes first if two of them
        //intersect in the path
        if (path.size() - other.path.size() != 0) {
            return path.size() - other.path.size();
        }

        return this.id - other.id;
    }

    // ### Buy & Sell ###
    public abstract int get_buying_price() throws UnauthorizedAction;
    public abstract int get_selling_price() throws UnauthorizedAction;
    public void reactToAreaChange() {
        // This method is called when the spot where the entity is positioned becomes protected or unproteted
        //it is redefined in predators
    }

}
