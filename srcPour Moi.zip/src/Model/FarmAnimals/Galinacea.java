package Model.FarmAnimals;

import Model.Spot;

public abstract class Galinacea extends FarmAnimal{

    public Galinacea(Spot s, int price) {
        super(s, price);
    }
}
