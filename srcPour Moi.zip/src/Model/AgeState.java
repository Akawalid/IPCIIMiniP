package Model;

public enum AgeState {
    BABY , MATURE, OLD, DEAD;
}
