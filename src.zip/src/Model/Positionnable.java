package Model;

import java.util.HashSet;

import static Model.Shepherd.FindPath.farm;
import static Model.Shepherd.Shepherd.PROTECTION_RADIUS;

public abstract class Positionnable {
    protected Spot position;
    public Positionnable(Spot position){
        assert (position != null);
        setPosition(position);
}

    /*public void setPosition(Spot position){

        assert (position != null);
        assert (position.isTraversable());

        if(this.position != null){
            //this.position is null only while creating the instance
            this.position.setIsTraversable(true);
            this.position.setPositionnable(null);
        }

        this.position = position;
        this.position.setPositionnable(this);
        this.position.setIsTraversable(false);
    }*/

    public void setPosition(Spot position) {
        if (position == null) {
            throw new IllegalArgumentException("La nouvelle position ne doit pas �tre null.");
        }
        if (!position.isTraversable()) {
            throw new IllegalArgumentException("La case n'est pas traversable.");
        }

        if (this.position != null) {
            // Lib�re l'ancienne position
            this.position.setIsTraversable(true);
            if (farm != null)
                farm.getChunk(this.position, PROTECTION_RADIUS);
            this.position.setPositionnable(null);
        }

        // Affecter la nouvelle position:
        this.position = position;
        this.position.setPositionnable(this);
        this.position.setIsTraversable(false);

        // (Le reste du code de gestion de la zone prot�g�e�)
    }

    public Spot getPosition(){
        //Invariant: position != null
        assert(position != null);
        return position;
    }

    public abstract void reactToAreaChange();
}
