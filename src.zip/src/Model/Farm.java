package Model;

import Model.FarmAnimals.FarmAnimal;
//import Model.Predators.FoxDen;
import Model.Predators.*;
import Model.Shepherd.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

//import static View.PredatorDenThread.MAX_DENS;

public class Farm {
    //Farm is out model, it contains the creatures and the land
    //each creature, has a reference to the spot on which it is standing.

    public static final int WIDTH = 35, HEIGHT = 20;//spots
    private Set<Entity> creatures;
    private ArrayList<Den> dens;
    private ArrayList<Spot> spots;
    private Bank bank;
    //this attribute represents the active entity on the farm, the one on which we want to apply operations
    private Entity selectedEntity;




    public Farm(){
        FindPath.farm = this;
        creatures = ConcurrentHashMap.newKeySet();
        spots = new ArrayList<>();
        dens = new ArrayList<>();

        bank = new Bank();

        initLand();
        selectedEntity = null;
        (new CleanDeadEntitiesThread(this)).start();
    }

    private void initLand(){
        //this method initiates the land, (fill).
        for (int i = 0; i < HEIGHT; i++){
            for (int j = 0; j < WIDTH; j++){
                spots.add(new Spot(i, j));
            }
        }
    }

    public Bank getBank(){
        return bank;
    }
    public Spot getSpot(int row, int col){
        // On suppose que WIDTH et HEIGHT définissent le nombre total de colonnes et de lignes.
        if(row < 0 || row >= HEIGHT || col < 0 || col >= WIDTH) {
            throw new IndexOutOfBoundsException("Coordonnées ("+ row + ", " + col + ") hors bornes");
        }
        return spots.get(row * WIDTH + col);
    }


    public boolean validCoordinates(int row, int col){
        //this method checks if the given coordinates are valid.
        return row >= 0
                && row < HEIGHT
                && col >= 0
                && col < WIDTH
                && getSpot(row, col).isTraversable();
    }
    public Iterator<Den> getDens(){
        return dens.iterator();
    }
    public Iterator<Entity> getEntities(){
        //this method returns an iterator of the creatures,
        //It is a good way to ensure abstraction.
        return creatures.iterator();
    }

    public void addEntity(Entity e){
        creatures.add(e);
    }

    public Entity getEntityInSpot(int row, int col){
        //TODO:Shlag
        Spot s = getSpot(row, col);
        for(Entity e: creatures)
            if(e.getPosition() == s) {
                return e;
            }
        return null;
    }
    public void launchMovementThread(int destRow, int destCol){
        ArrayDeque<Spot> queue = FindPath.findPath(
                selectedEntity.getPosition(),
                getSpot(destRow, destCol)
        );

        selectedEntity.setPath(queue);

        if(selectedEntity.getThread() == null || !selectedEntity.getThread().isAlive()){
            selectedEntity.startNewThread();
        }
    }
    public Entity getSelectedEntity(){return selectedEntity;}
    public void setSelectedEntity(Entity e){selectedEntity = e;}

    /**
     * Returns an adjacent free spot (i.e., traversable) to the given spot.
     * The search checks the eight neighbors (horizontal, vertical, and diagonal).
     *
     * @param s the reference spot
     * @return a free adjacent spot if one is found, or null otherwise.
     */
    public Spot getAdjacentFreeSpot(Spot s) {
        int row = s.getRow();
        int col = s.getCol();

        // Parcours des 8 voisins
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                // Ignorer le spot lui-m�me
                if (i == row && j == col)
                    continue;
                // V�rifier que les coordonnées sont valides
                if (i >= 0 && i < HEIGHT && j >= 0 && j < WIDTH) {
                    Spot candidate = getSpot(i, j);
                    if (candidate.isTraversable()) {
                        return candidate;
                    }
                }
            }
        }
        // Aucun spot libre trouvé
        return null;
    }

    public void cleanDeadEntities(){
        Iterator<Entity> it = creatures.iterator();
        while (it.hasNext()) {
            Entity e = it.next();
            if(e instanceof FarmAnimal) {
                FarmAnimal animal = (FarmAnimal) e;
                if (animal.getState() == AgeState.DEAD)
                    removeEntity(it, e);
            } else if(e instanceof Predator){
                Predator predator = (Predator) e;
                if (predator.getIsDead()){
                    removeEntity(it, e);
                }
            }

            // Suppression des dens morts en utilisant removeDen()
            List<Den> densToRemove = new ArrayList<>(dens);
            for (Den d : densToRemove) {
                if (!d.isActive()) {
                    removeDen(d);
                    System.out.println("Den supprimé automatiquement à (" + d.getPosition().getRow() + ", " + d.getPosition().getCol() + ")");
                }
            }
        }
    }

    /**
     * Updates the age of all farm animals and removes those that are dead.
     * This method is synchronized to prevent concurrent modifications.
     */
    public synchronized void updateEntities() {
        Iterator<Entity> it = creatures.iterator();
        while (it.hasNext()) {
            Entity e = it.next();
            if (e instanceof FarmAnimal) {
                FarmAnimal animal = (FarmAnimal) e;
                animal.updateAge();
                if (animal.getState() == AgeState.DEAD)
                    // Supprime en toute sécurité l'élément actuellement itéré
                    removeEntity(it, e);
            }
        }
    }

    public void generateDens() {
        // Optionnel : si vous souhaitez éviter des doublons lors d'appels successifs,
        // vous pouvez vérifier si la liste est déjà remplie ou la vider.
        if(!dens.isEmpty()){
            System.out.println("Des dens existent déjà, generation ignorée.");
            return;
        }

        Random rand = new Random();
        int numWolfDens = rand.nextBoolean() ? 1 : 2; // Génère 2 ou 3 dens de loup
        int numFoxDens   = rand.nextBoolean() ? 1 : 2; // Génère 2 ou 3 dens de renard

        // Création des WolfDens
        for (int i = 0; i < numWolfDens; i++) {
            Spot spot = getRandomTraversableSpot();
            if (spot == null) {
                System.out.println("Aucun spot traversable trouvé pour un WolfDen.");
                continue;
            }
            WolfDen wolfDen = new WolfDen(spot, this);
            dens.add(wolfDen);
            new Thread(wolfDen).start();
            System.out.printf("Den de loup créé à (%d, %d).%n", spot.getRow(), spot.getCol());
        }

        // Création des FoxDens
        for (int i = 0; i < numFoxDens; i++) {
            Spot spot = getRandomTraversableSpot();
            if (spot == null) {
                System.out.println("Aucun spot traversable trouvé pour un FoxDen.");
                continue;
            }
            FoxDen foxDen = new FoxDen(spot, this);
            dens.add(foxDen);
            new Thread(foxDen).start();
            System.out.printf("Den de renard créé à (%d, %d).%n", spot.getRow(), spot.getCol());
        }
    }


    // M�thode utilitaire pour obtenir une case traversable al�atoire
    private Spot getRandomTraversableSpot() {
        Random rand = new Random();
        while (true) {
            int row = rand.nextInt(HEIGHT);
            int col = rand.nextInt(WIDTH);
            Spot spot = getSpot(row, col);
            if (spot.isTraversable()) {
                return spot;
            }
        }
    }

    public void initPredators(int maxDens) {
        // Vérifier le nombre de dens déjà présentes :
        if (dens.size() >= maxDens) {
            System.out.printf("Nombre maximal de dens atteint (%d/%d).%n", dens.size(), maxDens);
            return; // On ne génère pas de nouveaux dens.
        }

        // Calculer le nombre de dens à créer
        int densToGenerate = maxDens - dens.size();
        System.out.printf("Génération de %d nouveaux dens.%n", densToGenerate);

        // Déterminer un nombre équilibré de dens de loup et de renard.
        // Par exemple, on répartit également si possible.
        int numWolfDens = densToGenerate / 2;
        int numFoxDens = densToGenerate - numWolfDens; // Pour gérer les cas impairs

        // Créer une liste pour spécifier quel type de den créer pour chaque slot
        List<Boolean> typeList = new ArrayList<>();
        // true signifie WolfDen, false signifie FoxDen
        for (int i = 0; i < numWolfDens; i++) {
            typeList.add(true);
        }
        for (int i = 0; i < numFoxDens; i++) {
            typeList.add(false);
        }

        // Mélanger la liste pour obtenir un ordre aléatoire
        java.util.Collections.shuffle(typeList);

        Random rand = new Random();
        for (Boolean isWolf : typeList) {
            Spot spot = getRandomTraversableSpot();
            if (isWolf) {
                WolfDen wolfDen = new WolfDen(spot, this);
                dens.add(wolfDen);
                System.out.printf("Den de loup créé à (%d, %d).%n", spot.getRow(), spot.getCol());
                new Thread(wolfDen).start();
            } else {
                FoxDen foxDen = new FoxDen(spot, this);
                dens.add(foxDen);
                System.out.printf("Den de renard créé à (%d, %d).%n", spot.getRow(), spot.getCol());
                new Thread(foxDen).start();
            }
        }
    }



    /**
     * Cette méthode vérifie si aucun bétail (Ewe, Sheep ou Hen) n'est présent dans le modèle.
     * Si c'est le cas, elle supprime toutes les structures de prédateurs, c'est-à-dire :
     * - Tous les Wolves de la collection creatures.
     * - Tous les Dens de la liste dens.
     * Ces suppressions libèrent également les Spots occupés, afin que la vue n'affiche plus ces entités.
     */
    public void removePredatorStructuresIfNoLivestock() {
        boolean hasLivestock = false;

        // Parcourir les entités (creatures) pour vérifier la présence de bétail
        for (Entity e : creatures) {
            if (e instanceof FarmAnimal) {
                String species = ((FarmAnimal) e).getSpecies();
                if (species.equals("Ewe") || species.equals("Sheep") || species.equals("Hen")) {
                    hasLivestock = true;
                    break;
                }
            }
        }

        // S'il n'y a aucun bétail présent, on retire les Wolves et les Dens.
        if (!hasLivestock) {
            // 1. Supprimer les Wolves de la collection creatures.
            Iterator<Entity> it = creatures.iterator();
            while (it.hasNext()) {
                Entity e = it.next();
                if (e instanceof Wolf) {
                    // Libérer la case occupée par le Wolf
                    e.getPosition().setIsTraversable(true);
                    e.getPosition().setPositionnable(null);
                    it.remove();
                }
            }
            // 2. Supprimer tous les Dens en utilisant la méthode removeDen.
            // Créer une copie de la liste pour éviter une modification concurrente lors de l'itération.
            List<Den> densToRemove = new ArrayList<>(dens);
            for (Den d : densToRemove) {
                removeDen(d);
            }

        }
    }


    public void removeEntity(Entity e){
        /** This method removes an entity from the farm
         * it is used when an entity dies or when it is removed from the farm
         */
        //remove from Spot
        e.getPosition().setIsTraversable(true);
        e.getPosition().setPositionnable(null);

        //remove from Farm
        creatures.remove(e);
        e.getPosition().setIsTraversable(true);
    }
    public void removeEntity(Iterator<Entity> it, Entity e){
        /** This method removes an entity from the farm
         * it is used when an entity dies or when it is removed from the farm
         */
        //remove from Spot
        e.getPosition().setIsTraversable(true);
        e.getPosition().setPositionnable(null);

        //remove from Farm
        it.remove();
    }
    public HashSet<Spot> getChunk(Spot s, int radius){
        /** This method returns a chunk of the farm
         * it is used to get the chunk of the farm that is visible on the screen
         */
        HashSet<Spot> chunk = new HashSet<>();
        for (int i = s.getRow() - radius; i <= s.getRow() + radius; i++){
            for (int j = s.getCol() - radius; j <= s.getCol() + radius; j++){
                if(
                        (i - s.getRow()) * (i - s.getRow())
                        +
                        (j - s.getCol()) * (j - s.getCol())
                        > radius * radius || i < 0 || i >= HEIGHT || j < 0 || j >= WIDTH
                ){
                    continue;
                }
                chunk.add(getSpot(i, j));
            }
        }
        return chunk;
    }


    /**
     * Supprime le Den du modèle.
     * Comme les Dens sont gérés uniquement dans la liste dédiée 'dens',
     * on le retire de cette liste. (Il n'est pas dans 'creatures')
     */
    public void removeDen(Den d) {

        // Désactiver le den pour stopper son thread
        d.active = false;
        // Libérer le Spot occupé par le Den.
        d.getPosition().setIsTraversable(true);
        d.getPosition().setPositionnable(null);
        // Retirer le Den de la liste dédiée.
        dens.remove(d);
    }

    /**
     * Retourne une liste de spots adjacents à un spot donné.
     * La recherche vérifie les quatre voisins (horizontal et vertical).
     *
     * @param s le spot de référence
     * @return une liste de spots adjacents
     */
    public List<Spot> getAdjacentSpots(Spot s) {
        List<Spot> neighbors = new ArrayList<>();
        int[][] directions = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };
        for (int[] d : directions) {
            int newRow = s.getRow() + d[0];
            int newCol = s.getCol() + d[1];
            if (newRow >= 0 && newRow < HEIGHT && newCol >= 0 && newCol < WIDTH) {
                neighbors.add(getSpot(newRow, newCol));
            }
        }
        return neighbors;
    }

    public void debugDens() {
        System.out.println("---- Etat des Dens ----");
        if(dens.isEmpty()) {
            System.out.println("Aucun Den présent.");
        } else {
            for (Den d : dens) {
                System.out.printf("Den à (%d, %d) - active: %b%n",
                        d.getPosition().getRow(),
                        d.getPosition().getCol(),
                        d.isActive());
            }
        }
        System.out.println("FIN DEBUG DENS\n");
    }



    public boolean hasActiveDens() {
        for (Den d : dens) {
            if (d.isActive()) {
                return true;
            }
        }
        return false;
    }

}