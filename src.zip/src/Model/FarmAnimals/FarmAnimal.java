package Model.FarmAnimals;

import Model.Bank;
import Model.Entity;
import Model.AgeState;
import Model.Exceptions.UnauthorizedAction;
//import Model.Predators.FoxDen;
import Model.Resources.Resource;
import Model.Spot;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import static Model.AgeState.*;

public abstract class FarmAnimal extends Entity {

    //------------------- Attributes -------------------//

    private final int PRICE;
    // ### Age evolution ###

    private int age;       // L'�ge exprim� en nombre de cycles
    protected AgeState state;  // "B�b�", "Mature", "Vieux"

    // ### Resource production ###
    ArrayList<Resource> resourceList;

    //------------------- Methods -------------------//

    /** constructor **/
    public FarmAnimal(Spot s, int price) {
        super(s);
        //Age evolution
        // Initialiser � b�b�
        this.age = 0;
        this.state = BABY;
        //Resource production
        resourceList = new ArrayList<>();
        PRICE = price;
    }

    // ### Age evolution ###

    public final void updateAge() {
        // Si l'animal est d�j� mort, on ne fait rien
        if (state == DEAD) {
            return;
        }
        age++;
        if (age>3 && age<7) {
            state = MATURE;
            // TODO:  Possibilit� d'augmenter la production ou la reproduction � cet �tat
        } else if (age > 7 && age < 10) {
            state = OLD;
            // TODO : R�duire la production et / ou la valeur de revente, par exemple
        } else if (age == 10) {
            // L'animal meurt de vieillesse
            System.out.println("L'animal est mort de vieillesse.");
            state = DEAD;
        }
        System.out.println("�ge : " + age + " - �tat : " + state);
    }

    public Object getState() {
        return state;
    }

    public int getAge() {
        return age;
    }

    // ### Resource production ###

    public Iterator<Resource> getResources() {
        return resourceList.iterator();
    }
    @Override
    public int get_buying_price() {
        return PRICE;
    }
    @Override
    public int get_selling_price() throws UnauthorizedAction {
        if (this.state == MATURE) {
            return PRICE/2;
        }
        if (this.state == OLD) {
            return PRICE/10;
        }

        if(state == DEAD)
            //Theoretically, it's impossible to enter this part of the code, because a dead animal disappears
            throw new UnauthorizedAction("Impossible to sell a dead animal.");
        else
            throw new UnauthorizedAction("Impossible to sell a BABY farm animal.");
    }
}