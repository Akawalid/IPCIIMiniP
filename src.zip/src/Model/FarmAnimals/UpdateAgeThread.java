package Model.FarmAnimals;

import Model.Farm;

/**
 * Simulation thread that updates the model's state.
 * This thread iterates over all the entities in the farm and calls updateAge()
 * on objects of type FarmAnimal at regular intervals.
 */
public class UpdateAgeThread extends Thread {
    // Update delay in milliseconds (5 seconds)
    public static final int UPDATE_DELAY = 5000;
    private Farm farm;

    private boolean active = true;

    /**
     * Constructor that initializes the thread with the farm.
     * @param farm the farm containing the entities to be updated.
     */
    public UpdateAgeThread(Farm farm) {
        this.farm = farm;
    }

    public void stopThread(){
        active = false;
    }

    @Override
    public void run() {
        while (active) {
            // Call the synchronized updateEntities method in Farm
            farm.updateEntities();
            try {
                Thread.sleep(UPDATE_DELAY); // Pause 5s before the next update
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}