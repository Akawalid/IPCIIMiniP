package Model.Shepherd;

import Model.*;
import Model.Exceptions.InvalidCoordinates;
import Model.Exceptions.UnauthorizedAction;
import Model.Predators.Predator;
import Model.Predators.Den;

import java.util.HashSet;

public class Shepherd extends Entity {
    public static final int DELAY_SHEPHERD = 100;
    public static int PROTECTION_RADIUS = 3;
    private final int PRICE = 80;
    private final Farm farm;

    private EntityMovementThread thread;

    public Shepherd(Spot s, Farm farm) {
        super(s);
        this.farm = farm;
    }
    public void setPosition(Spot position){
        assert (position != null);
        assert (position.isTraversable());
        HashSet<Spot> chunk = new HashSet<>();
        if(this.position != null){
            //this.position is null only while creating the instance
            this.position.setIsTraversable(true);
            if (farm != null)
                chunk = farm.getChunk(this.position, PROTECTION_RADIUS);


            this.position.setPositionnable(null);
        }

        this.position = position;
        this.position.setPositionnable(this);
        this.position.setIsTraversable(false);
        if(farm != null)
            for(Spot s: farm.getChunk(this.position, PROTECTION_RADIUS)){
                if(chunk.contains(s)){
                    chunk.remove(s);
                    s.setIsProtectedArea(true);
                }
            }
        for(Spot s: chunk){
            System.out.println("aaaaaaaaaaaa " + s.getRow() + "; " + s.getCol());
            s.setIsProtectedArea(false);
        }



    // Supprimer les terriers situ�s dans les 8 voisins (diagonaux inclus) du bergerif (farm != null) {
           /* int shepherdRow = this.position.getRow();
            int shepherdCol = this.position.getCol();
            for (int i = shepherdRow - 1; i <= shepherdRow + 1; i++) {
                for (int j = shepherdCol - 1; j <= shepherdCol + 1; j++) {
                    // Ignorer la case du berger lui-m�me
                    if (i == shepherdRow && j == shepherdCol)
                        continue;
                    if (i >= 0 && i < Farm.HEIGHT && j >= 0 && j < Farm.WIDTH) {
                        Spot neighborSpot = farm.getSpot(i, j);
                        if (neighborSpot.getPositionnable() instanceof Den) {
                            Den den = (Den) neighborSpot.getPositionnable();
                            farm.removeDen(den);
                        }
                    }
                }
            }
        }*/

        // Suppression des pr�dateurs se trouvant dans la zone prot�g�e par le berger
        /*if (farm != null) {
            HashSet<Spot> protectionArea = farm.getChunk(this.position, PROTECTION_RADIUS);
            for (Spot s : protectionArea) {
                // Ignorer la case du berger lui-m�me
                if (s == this.position) continue;
                if (s.getPositionnable() instanceof Predator) {
                    Predator predator = (Predator) s.getPositionnable();
                    predator.getPosition().setIsTraversable(true);
                    predator.getPosition().setPositionnable(null);

                    farm.removeEntity(predator);
                }
            }
        }*/
    }

    @Override
    public String getSpecies() {
        return "Shepherd";
    }

    @Override
    public int get_buying_price() {
        return PRICE;
    }

    @Override
    public int get_selling_price() throws UnauthorizedAction {
        return 0;
    }

}