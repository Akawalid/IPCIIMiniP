package Model;

import Model.Exceptions.InvalidCoordinates;
import Model.Shepherd.Shepherd;

import java.util.Iterator;

import static Model.Predators.Predator.DELAY_PREDATOR;
import static Model.Shepherd.Shepherd.DELAY_SHEPHERD;

public class EntityMovementThread extends Thread {
    //public static final int DELAY = 1000;
    private Entity e;
    public EntityMovementThread(Entity e){

        this.e = e;
    }
    @Override
    public void run() {
        while(e.hasMovements()) {
            try {
                e.move();
                Thread.sleep(e instanceof Shepherd ? DELAY_SHEPHERD : DELAY_PREDATOR);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (InvalidCoordinates e) {
                //We have to display for the ser an error invalid coordinates
                System.out.print("Invalid coordinates: ShepherdMovementThread, line: 21");
            }
        }
    }
}
