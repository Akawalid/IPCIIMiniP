package Model;

import Model.Predators.Wolf;
import java.util.Iterator;

public class TestRemoveEntity {
    public static void main(String[] args) {
        // Cr�er une instance de Farm
        Farm farm = new Farm();

        // Utiliser des spots existants dans la ferme (supposons que initLand a �t� appel� dans le constructeur)
        Spot spot1 = farm.getSpot(0, 0);
        Spot spot2 = farm.getSpot(0, 1);
        Spot spot3 = farm.getSpot(0, 2);

        // Cr�er trois instances de Wolf
        Wolf wolf1 = new Wolf(spot1, farm);
        Wolf wolf2 = new Wolf(spot2, farm);
        Wolf wolf3 = new Wolf(spot3, farm);

        // Les ajouter � la collection globale via addEntity (elles seront stock�es dans 'creatures')
        farm.addEntity(wolf1);
        farm.addEntity(wolf2);
        farm.addEntity(wolf3);

        // Afficher le nombre initial d'entit�s dans la ferme (devrait �tre 3)
        System.out.println("Nombre initial d'entit�s : " + countEntities(farm));

        // Supprimer l'instance wolf2 � l'aide d'un Iterator
        Iterator<Entity> it = farm.getEntities();
        while(it.hasNext()){
            Entity e = it.next();
            if(e == wolf2) {
                // Cette m�thode supprime l'entit� de la collection originale
                farm.removeEntity(it, e);
            }
        }

        // Afficher le nombre d'entit�s apr�s suppression (devrait �tre 2)
        System.out.println("Nombre d'entit�s apr�s suppression de wolf2 : " + countEntities(farm));
    }

    private static int countEntities(Farm farm) {
        int count = 0;
        for (Iterator<Entity> it = farm.getEntities(); it.hasNext(); ) {
            Entity e = it.next();
            count++;
        }
        return count;
    }
}
