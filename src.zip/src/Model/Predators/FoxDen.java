package Model.Predators;

import Model.Exceptions.UnauthorizedAction;
import Model.Farm;
import Model.Spot;

public class FoxDen extends Den {

    public FoxDen(Spot s, Farm farm) {
        super(s, farm);
    }

    @Override
    protected void spawnPredator() {
        if (!this.active) {
            System.out.printf("Tentative de spawn annul�e car le Den � (%d, %d) est inactif.%n",
                    this.getPosition().getRow(), this.getPosition().getCol());
            return;
        }
        Spot spawnSpot = farm.getAdjacentFreeSpot(this.getPosition());
        if (spawnSpot != null) {
            Fox fox = new Fox(spawnSpot, farm);
            fox.setParentDen(this);
            farm.addEntity(fox);
            new Thread(fox).start();
            System.out.printf("Spawn d'un Fox depuis le Den � (%d, %d) sur le spot (%d, %d).%n",
                    this.getPosition().getRow(), this.getPosition().getCol(),
                    spawnSpot.getRow(), spawnSpot.getCol());
        } else {
            System.out.printf("Aucun spot libre trouv� pour le Den � (%d, %d) pour spawn un Fox.%n",
                    this.getPosition().getRow(), this.getPosition().getCol());
        }
    }


}
