/*package Model.Predators;

import Model.Entity;
import Model.Farm;
import Model.Predators.Fox;
import java.util.Iterator;

public class TestFoxPropagation {
    public static void main(String[] args) {
        // Cr�ation de la ferme et initialisation du terrain
        Farm farm = new Farm();

        // Initialisation des dens de pr�dateurs (g�n�re � la fois des dens de loups et des dens de renards)
        farm.initPredators();

        // Boucle d'observation : toutes les 5 secondes, on compte le nombre de Fox
        for (int i = 0; i < 6; i++) {
            try {
                Thread.sleep(5000); // Pause de 5 secondes
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            int foxCount = 0;
            Iterator<Entity> iterator = farm.getEntities();
            while (iterator.hasNext()) {
                Entity e = iterator.next();
                if (e instanceof Fox) {
                    foxCount++;
                }
            }
            System.out.println("Apr�s " + ((i + 1) * 5) + " secondes, nombre de Fox : " + foxCount);
        }

        System.out.println("Test termin�.");
    }
}*/