package Model.Predators;

import Model.Farm;
import Model.Spot;

public class WolfDen extends Den {
    public WolfDen(Spot s, Farm farm) {
        super(s, farm);
    }

    @Override
    protected void spawnPredator() {
        System.out.println("spawnPredator() appel�e pour le Den � (" + this.getPosition().getRow() + ", " + this.getPosition().getCol() + ")");
        if (!this.active) {
            System.out.printf("Tentative de spawn annul�e car le Den � (%d, %d) est inactif.%n",
                    this.getPosition().getRow(), this.getPosition().getCol());
            return;
        }
        Spot spawnSpot = farm.getAdjacentFreeSpot(this.getPosition());
        if (spawnSpot != null) {
            Wolf wolf = new Wolf(spawnSpot, farm);
            wolf.setParentDen(this);
            farm.addEntity(wolf);
            System.out.printf("Spawn d'un Wolf depuis le Den � (%d, %d) sur le spot (%d, %d).%n",
                    this.getPosition().getRow(), this.getPosition().getCol(),
                    spawnSpot.getRow(), spawnSpot.getCol());
            new Thread(wolf).start();
        } else {
            System.out.printf("Aucun spot libre trouv� pour le Den � (%d, %d) pour spawn un Wolf.%n",
                    this.getPosition().getRow(), this.getPosition().getCol());
        }
    }



}