package Model.Exceptions;

public class UnauthorizedAction extends Exception {
    public UnauthorizedAction(String message) {
        super(message);
    }
}
