package View.ControlPanelComponents.Information;

/* Enum PurchaseTyp representing the types of purchases available in the market */
public enum PurchaseType {
    SHEEP,
    EWE,
    HEN,
    SHEPHERD
}
