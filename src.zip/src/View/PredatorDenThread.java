/*package View;

import Model.Farm;
import View.World;

public class PredatorDenThread extends Thread { // TODO continuer l'impl�mentation en fonction de la classe ROUND DE AILEEN 
    private final Farm farm;
    private final World world;
    public static final int INITIALIZATION_DELAY = 10000; // toutes les 10 secondes

    public static final int MAX_DENS = 5; // Nombre maximum de dens actives


    public PredatorDenThread(Farm farm, World world) {
        this.farm = farm;
        this.world = world;
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            System.out.println("Initialisation p�riodique des dens de pr�dateurs...");
            farm.initPredators(MAX_DENS);

            // Forcer le rafra�chissement de la vue
            javax.swing.SwingUtilities.invokeLater(() -> {
                world.repaint();
                world.revalidate();
            });

            try {
                Thread.sleep(INITIALIZATION_DELAY);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("Thread PredatorDenInitializer arr�t�.");
    }
}
*/